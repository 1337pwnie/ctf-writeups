Hi there.
We just encrypted all of the files on your hard drive using a
perfectly-secure one time pad. It is impossible to crack as the
xor operation cannot be reversed. Look at the code if you want
and see for yourself. To get your files back, send 2BTC to
1NgiUwkhYVYMy3eoMC9dHcvdHejGxcuaWm and we will send you a key
that will unlock all of your files.
Your files:
	Archive.zip
	bae.gif
	beemovie.whitespace
	decrypt_diary.py
	diary.ecb
	fire_meme.jpg
	lossless_meme.png
	motivational.txt
	print_flag
	protect_diary.py
	special_meme.jpg.b64
	wikipedia_fair_use_sample.ogg
